package com.example.cp2

import android.graphics.Color
import android.graphics.ColorSpace.Rgb
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.example.cp2.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    companion object {
        private const val rgb = "RGB"
        private const val color = "COLOR_PICKER"
    }
    private var currentVisibleView: String = rgb


   private var binding: ActivityMainBinding? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding?.root)

        setSupportActionBar(binding?.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "color"
        binding?.toolbar?.setNavigationOnClickListener {
            onBackPressed()
        }

        makeVisibleRGBView()
        binding?.radioGroup?.setOnCheckedChangeListener { _, checkedId: Int ->
            if (checkedId == R.id.radioButton2) {
                makeVisibleRGBView()
            } else {
                makeVisibleColorPicker()
            }
        }

        val red = binding?.editTextText?.text.toString()

        val green = binding?.editTextText2?.text.toString()

        val blue = binding?.editTextText3?.text.toString()

        val color = ("$red$green$blue")


        binding?.button?.setOnClickListener {

        }
    }

    private fun makeVisibleColorPicker() {
        currentVisibleView = rgb
        binding?.editTextText?.visibility =View.INVISIBLE
        binding?.editTextText2?.visibility =View.INVISIBLE
        binding?.editTextText3?.visibility =View.INVISIBLE
        binding?.imageView?.visibility = View.INVISIBLE
        binding?.imageView2?.visibility = View.INVISIBLE
        binding?.imageView3?.visibility = View.INVISIBLE
    }

    private fun makeVisibleRGBView() {
        currentVisibleView = rgb
        binding?.editTextText?.visibility =View.VISIBLE
        binding?.editTextText2?.visibility =View.VISIBLE
        binding?.editTextText3?.visibility =View.VISIBLE
        binding?.imageView?.visibility = View.VISIBLE
        binding?.imageView2?.visibility = View.VISIBLE
        binding?.imageView3?.visibility = View.VISIBLE

    }

}